package model;

import java.beans.DesignMode;
import java.util.ArrayList;

public class User {

    private static final ArrayList<User> users = new ArrayList<User>();
    private static User loggedInUser = null;
    private ArrayList<Card> cards;
    private ArrayList<Card> deck;
    private Card[] bench;
    private String username;
    private String password;
    private String email;
    private int coins;
    private int experience;
    private int kills;
    private double reduce;

    public User(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.cards = new ArrayList<Card>();
        this.deck = new ArrayList<Card>();
        this.bench = new Card[4];
        for (int i = 0; i < 4; i++) this.bench[i] = null;
        this.coins = 300;
        this.experience = 0;
        this.kills = 0;
        this.reduce = 0d;
    }

    public static User getLoggedInUser() {
        return loggedInUser;
    }

    public static void setLoggedInUser(User user) {
        loggedInUser = user;
        return;
    }

    public static void addUser(User user) {
        users.add(user);
        return;
    }

    public static User getUserByUsername(String username) {
        for (User user : users) {
            if (user.username.equals(username)) return user;
        }
        return null;
    }

    public static ArrayList<User> getSortedRanking() {
        ArrayList<User> newUsers = new ArrayList<User>();
        for (User user : users) newUsers.add(user);
        for (int count = newUsers.size() - 1; count >= 1; count--) {
            for (int i = 0; i < count; i++) {
                User user1 = newUsers.get(i), user2 = newUsers.get(i + 1);
                if (isBigger(user1, user2)) {
                    newUsers.set(i, user2);
                    newUsers.set(i + 1, user1);
                }
            }
        }
        return newUsers;
    }

    public static boolean isBigger(User user1, User user2) {
        if (user1.getExperience() < user2.getExperience()) return true;
        return (user1.getExperience() == user2.getExperience() && user1.getUsername().compareTo(user2.getUsername()) > 0);
    }

    public String getUsername() {
        return this.username;
    }

    public String getPassword() {
        return this.password;
    }

    public int getCoins() {
        return this.coins;
    }

    public void setCoins(int coins) {
        this.coins = coins;
        return;
    }

    public int getExperience() {
        return this.experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
        return;
    }

    public ArrayList<Card> getCards() {
        return this.cards;
    }

    public ArrayList<Card> getDeck() {
        return this.deck;
    }

    private int getDeckCount() {
        return this.deck.size();
    }

    public Card getCardInDeckByName(String name) {
        for (Card card : this.deck) {
            if (card.getName().equals(name)) return card;
        }
        return null;
    }

    public Card getCardInCardsMinusDeckByName(String name) {
        for (Card card : this.cards) {
            if (this.haveCardInDeck(card)) continue;
            if (card.getName().equals(name)) return card;
        }
        return null;
    }

    public Card getCardInCardsByName(String name) {
        for (Card card : this.cards) {
            if (card.getName().equals(name)) return card;
        }
        return null;
    }

    public Card[] getBench() {
        return this.bench;
    }

    public Card getCardInBench(int placeNumber) {
        return this.bench[placeNumber];
    }

    public void setCardInBench(Card newCard, int placeNumber) {
        this.bench[placeNumber] = newCard;
        return;
    }

    public boolean haveCardInDeck(Card cardToFind) {
        for (Card card : this.deck) {
            if (card == cardToFind) return true;
        }
        return false;
    }

    public int getKills() {
        return this.kills;
    }

    public void setKills(int kills) {
        this.kills = kills;
        return;
    }

    public double getReduce() {
        return this.reduce;
    }

    public void setReduce(double reduce) {
        this.reduce = reduce;
        return;
    }

    public int getRank() {
        ArrayList<User> ranking = User.getSortedRanking();
        for (int i = 0; i < ranking.size(); i++) {
            if (ranking.get(i) == this) return i + 1;
        }
        return -1;
    }

    public boolean canBuyCard(String cardName) {
        return (this.getCoins() >= Card.getBuyPriceByName(cardName));
    }

    public boolean hasFullDeck() {
        return (this.getDeckCount() >= 12);
    }

    public void equipToDeck(Card card) {
        this.deck.add(card);
        return;
    }

    public void unequipFromDeck(Card card) {
        this.deck.remove(card);
        return;
    }

    public void addToBench(Card card, int placeNumber) {
        this.bench[placeNumber] = card;
        return;
    }

    public void removeFromDeck(Card card) {
        this.deck.remove(card);
        return;
    }

    public void removeFromCards(Card card) {
        this.cards.remove(card);
        return;
    }

    public void substituteActiveCard(int placeNumber) {
        Card temp = this.getCardInBench(0);
        this.bench[0] = this.getCardInBench(placeNumber);
        this.bench[placeNumber] = temp;
        return;
    }

    public void buyCard(String cardName) {
        int price = Card.getBuyPriceByName(cardName);
        this.coins -= price;
        Card newCard = new Card(cardName, Card.getTypeByName(cardName), this);
        this.cards.add(newCard);
        return;
    }

    public void sellCard(Card card) {
        this.cards.remove(card);
        this.deck.remove(card);
        this.coins += Card.getSellPriceByName(card.getName());
        return;
    }

    public void initializeForGame() {
        for (int i = 0; i < 4; i++) this.bench[i] = null;
        this.kills = 0;
        this.reduce = 0d;
        for (Card card : this.deck) {
            card.initializeForGame();
        }
        return;
    }

}
