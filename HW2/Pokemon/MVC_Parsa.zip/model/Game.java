package model;

import java.util.ArrayList;

public class Game {

    private static Game currentGame = null;
    private int roundNumber;
    private User gameStarterUser;
    private User currentPlayer;
    private User nextPlayer;
    private boolean usedEnergy;
    private ArrayList<Card> burningInNextRound;
    private ArrayList<Card> sleepingInNextRound;

    public Game(User firstPlayer, User secondPlayer) {
        this.gameStarterUser = firstPlayer;
        this.currentPlayer = firstPlayer;
        this.nextPlayer = secondPlayer;
        this.roundNumber = 1;
        this.usedEnergy = false;
        this.burningInNextRound = new ArrayList<Card>();
        this.sleepingInNextRound = new ArrayList<Card>();
    }

    public static Game getCurrentGame() {
        return currentGame;
    }

    public static void setCurrentGame(Game game) {
        currentGame = game;
        return;
    }

    public int getRoundNumber() {
        return this.roundNumber;
    }

    public void increaseRoundNumber() {
        this.roundNumber++;
        return;
    }

    public User getCurrentPlayer() {
        return this.currentPlayer;
    }

    public void setCurrentPlayer(User currentPlayer) {
        this.currentPlayer = currentPlayer;
        return;
    }

    public User getNextPlayer() {
        return this.nextPlayer;
    }

    public void setNextPlayer(User nextPlayer) {
        this.nextPlayer = nextPlayer;
        return;
    }

    public User getGameStarterUser() {
        return this.gameStarterUser;
    }

    public boolean hasUsedEnergy() {
        return this.usedEnergy;
    }

    public void setUsedEnergy(boolean usedEnergy) {
        this.usedEnergy = usedEnergy;
        return;
    }

    public ArrayList<Card> getBurningInNextRound() {
        return this.burningInNextRound;
    }

    public void clearBurningInNextRound() {
        this.burningInNextRound.clear();
        return;
    }

    public ArrayList<Card> getSleepingInNextRound() {
        return this.sleepingInNextRound;
    }

    public void clearSleepingInNextRound() {
        this.sleepingInNextRound.clear();
        return;
    }

    public User getOtherPlayer(User player) {
        if (player == this.currentPlayer) return this.nextPlayer;
        return this.currentPlayer;
    }

    public void addToBurningInNextRound(Card card) {
        this.burningInNextRound.add(card);
        return;
    }

    public void addToSleepingInNextRound(Card card) {
        this.sleepingInNextRound.add(card);
        return;
    }

    public void killCard(Card card) {
        User owner = card.getOwner();
        User enemy = this.getOtherPlayer(owner);
        if (card.isEnergy()) {
            enemy.setKills(enemy.getKills() + 1);
            return;
        }
        enemy.setKills(enemy.getKills() + 1 + card.getEnergyCount());
        enemy.setReduce(enemy.getReduce() + (double) Card.getMaxhitpointByName(card.getName()));
    }
}
