package model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Objects;
import java.util.SimpleTimeZone;

public class Card {

    private static final HashMap<String, Integer> buyPrices = new HashMap<String, Integer>();
    private static final HashMap<String, Integer> sellPrices = new HashMap<String, Integer>();
    private static final HashSet<String> cardNames = new HashSet<String>();
    private static final HashMap<String, Integer> maxHitpoints = new HashMap<String, Integer>();
    private static final HashMap<String, Integer> powers = new HashMap<String, Integer>();
    private static final HashMap<String, HashMap<String, Double> > weaknesses = new HashMap<String, HashMap<String, Double> >();
    private static final HashMap<String, HashMap<String, Double> > energyMultipliers = new HashMap<String, HashMap<String, Double> >();
    private static final HashMap<String, Double> resistances = new HashMap<String, Double>();
    private static final HashMap<String, String> cardTypes = new HashMap<String, String>();
    private Card[] energies;
    private String name;
    private String type;
    private User owner;
    private double hitpoint;
    private boolean sleeping;
    private boolean burning;

    static {
        buyPrices.put("dragonite", 10);
        buyPrices.put("tepig", 13);
        buyPrices.put("lugia", 11);
        buyPrices.put("ducklett", 15);
        buyPrices.put("pineco", 9);
        buyPrices.put("rowlet", 12);
        buyPrices.put("pink", 5);
        buyPrices.put("yellow", 5);
        sellPrices.put("dragonite", 8);
        sellPrices.put("tepig", 10);
        sellPrices.put("lugia", 9);
        sellPrices.put("ducklett", 11);
        sellPrices.put("pineco", 7);
        sellPrices.put("rowlet", 9);
        sellPrices.put("pink", 3);
        sellPrices.put("yellow", 3);
        cardNames.add("dragonite");
        cardNames.add("tepig");
        cardNames.add("lugia");
        cardNames.add("ducklett");
        cardNames.add("pineco");
        cardNames.add("rowlet");
        cardNames.add("pink");
        cardNames.add("yellow");
        maxHitpoints.put("dragonite", 120);
        maxHitpoints.put("tepig", 140);
        maxHitpoints.put("lugia", 90);
        maxHitpoints.put("ducklett", 70);
        maxHitpoints.put("pineco", 110);
        maxHitpoints.put("rowlet", 180);
        powers.put("dragonite", 40);
        powers.put("tepig", 25);
        powers.put("lugia", 20);
        powers.put("ducklett", 20);
        powers.put("pineco", 25);
        powers.put("rowlet", 40);
        resistances.put("dragonite", 0.7d);
        resistances.put("tepig", 0.8d);
        resistances.put("lugia", 0.7d);
        resistances.put("ducklett", 0.6d);
        resistances.put("pineco", 0.9d);
        resistances.put("rowlet", 0.5d);
        weaknesses.put("dragonite", new HashMap<String, Double>());
        weaknesses.get("dragonite").put("water", 1.2d);
        weaknesses.put("tepig", new HashMap<String, Double>());
        weaknesses.get("tepig").put("water", 2d);
        weaknesses.get("tepig").put("plant", 1.3d);
        weaknesses.put("lugia", new HashMap<String, Double>());
        weaknesses.get("lugia").put("fire", 1.3d);
        weaknesses.put("ducklett", new HashMap<String, Double>());
        weaknesses.get("ducklett").put("plant", 1.5d);
        weaknesses.put("rowlet", new HashMap<String, Double>());
        weaknesses.get("rowlet").put("fire", 1.3d);
        energyMultipliers.put("fire", new HashMap<String, Double>());
        energyMultipliers.get("fire").put("pink", 1d);
        energyMultipliers.get("fire").put("yellow", 1d);
        energyMultipliers.put("water", new HashMap<String, Double>());
        energyMultipliers.get("water").put("pink", 1.05d);
        energyMultipliers.get("water").put("yellow", 1.2d);
        energyMultipliers.put("plant", new HashMap<String, Double>());
        energyMultipliers.get("plant").put("pink", 1.15d);
        energyMultipliers.get("plant").put("yellow", 1.2d);
        cardTypes.put("dragonite", "fire");
        cardTypes.put("tepig", "fire");
        cardTypes.put("lugia", "water");
        cardTypes.put("ducklett", "water");
        cardTypes.put("pineco", "plant");
        cardTypes.put("rowlet", "plant");
        cardTypes.put("pink", "energy");
        cardTypes.put("yellow", "energy");
    }

    public Card(String name, String type, User owner) {
        this.name = name;
        this.type = type;
        this.owner = owner;
        this.energies = new Card[2];
        for (int i = 0; i < 2; i++) this.energies[i] = null;
        this.hitpoint = Card.getMaxhitpointByName(name);
        this.sleeping = false;
        this.burning = false;
    }

    public static int getBuyPriceByName(String name) {
        return buyPrices.get(name);
    }

    public static int getSellPriceByName(String name) {
        return sellPrices.get(name);
    }

    public static int getMaxhitpointByName(String name) {
        if (!maxHitpoints.containsKey(name)) return -1;
        return maxHitpoints.get(name);
    }

    public static int getPowerByName(String name) {
        if (!powers.containsKey(name)) return -1;
        return powers.get(name);
    }

    public static double getResistance(String name) {
        return resistances.get(name);
    }

    public static double getEnergyMultiplier(String type, String energyName) {
        return energyMultipliers.get(type).get(energyName);
    }

    public static double getWeakness(String cardName, String type) {
        if (!weaknesses.containsKey(cardName)) return 1d;
        if (!weaknesses.get(cardName).containsKey(type)) return 1d;
        return weaknesses.get(cardName).get(type);
    }

    public static String getTypeByName(String cardName) {
        return cardTypes.get(cardName);
    }

    public static boolean isValidCardName(String name) {
        return (cardNames.contains(name));
    }

    public String getName() {
        return this.name;
    }

    public String getType() {
        return this.type;
    }

    public User getOwner() {
        return this.owner;
    }

    public Card[] getEnergies() {
        return this.energies;
    }

    public boolean isBurning() {
        return this.burning;
    }

    public void setBurning(boolean burning) {
        this.burning = burning;
        return;
    }

    public boolean isSleeping() {
        return this.sleeping;
    }

    public void setSleeping(boolean sleeping) {
        this.sleeping = sleeping;
        return;
    }

    public double getHitpoint() {
        return this.hitpoint;
    }

    public void setHitpoint(double hitpoint) {
        this.hitpoint = hitpoint;
        return;
    }

    public Card getEnergyInEnergies(int placeNumber) {
        return this.energies[placeNumber];
    }

    public boolean isEnergy() {
        return (this.getName().equals("pink") || this.getName().equals("yellow"));
    }

    public boolean isPokemon() {
        return (!this.isEnergy());
    }

    public int getEnergyCount() {
        int counter = 0;
        for (int i = 0; i < 2; i++) {
            if (this.energies[i] != null) counter++;
        }
        return counter;
    }

    public void removeOneEnergy() {
        Card energy = this.getEnergyInEnergies(0);
        if (energy == null) return;
        Game.getCurrentGame().killCard(energy);
        this.energies[0] = this.getEnergyInEnergies(1);
        this.energies[1] = null;
        return;
    }

    public double getDamageOrHealAmount(String defenderName) {
        double answer = -1d;
        if (this.type.equals("plant")) answer = 1d;
        answer *= (double) Card.getPowerByName(this.getName());
        Card energy = this.getEnergyInEnergies(0);
        if (energy != null) answer *= Card.getEnergyMultiplier(this.type, energy.getName());
        energy = this.getEnergyInEnergies(1);
        if (energy != null) answer *= Card.getEnergyMultiplier(this.type, energy.getName());
        answer *= Card.getResistance(defenderName);
        answer *= Card.getWeakness(defenderName, this.type);
        return answer;
    }

    public void takeDamageOrHeal(double x) {
        if (x < 0d && this.type.equals("plant")) {
            x += 15d;
            if (x > 0d) x = 0d;
        }
        this.hitpoint += x;
        return;
    }

    public boolean canAddEnergy() {
        return (this.getEnergyCount() < 2);
    }

    public void addEnergy(Card energy) {
        if (this.getEnergyInEnergies(0) == null) {
            this.energies[0] = energy;
            return;
        }
        if (this.getEnergyInEnergies(1) == null) {
            this.energies[1] = energy;
        }
        return;
    }

    public void initializeForGame() {
        for (int i = 0; i < 2; i++) this.energies[i] = null;
        this.hitpoint = (double) Card.getMaxhitpointByName(this.getName());
        this.sleeping = false;
        this.burning = false;
        return;
    }

    public void paralyze() {
        this.removeOneEnergy();
        this.removeOneEnergy();
        return;
    }

    @Override
    public String toString() {
        StringBuilder answer = new StringBuilder("");
        answer.append(this.getName());
        answer.append("|");
        Card energy = this.getEnergyInEnergies(0);
        if (energy != null) answer.append(energy.getName());
        answer.append("|");
        energy = this.getEnergyInEnergies(1);
        if (energy != null) answer.append(energy.getName());
        return answer.toString();
    }
}
