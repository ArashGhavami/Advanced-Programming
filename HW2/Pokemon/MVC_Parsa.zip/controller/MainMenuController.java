package controller;

import model.Game;
import model.User;

import java.util.regex.Matcher;

public class MainMenuController {

    public static String startNewGame(Matcher matcher) {
        String username = matcher.group("username");
        User user = User.getUserByUsername(username);
        if (user == null) return "username is incorrect";
        User loggedInUser = User.getLoggedInUser();
        if (!loggedInUser.hasFullDeck()) return loggedInUser.getUsername() + " has no 12 cards in deck";
        if (!user.hasFullDeck()) return user.getUsername() + " has no 12 cards in deck";
        Game game = new Game(loggedInUser, user);
        loggedInUser.initializeForGame();
        user.initializeForGame();
        Game.setCurrentGame(game);
        return "ok";
    }
}
