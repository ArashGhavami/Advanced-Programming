package controller;

import model.*;

import java.util.ArrayList;
import java.util.regex.Matcher;

public class GameMenuController {

    private static Card defender;

    public static String showTable() {
        Game currentGame = Game.getCurrentGame();
        StringBuilder answer = new StringBuilder("");
        answer.append("round ");
        answer.append(currentGame.getRoundNumber());
        answer.append("\nyour active card:\n");
        User currentPlayer = currentGame.getCurrentPlayer();
        User nextPlayer = currentGame.getNextPlayer();
        Card tempCard = currentPlayer.getCardInBench(0);
        if (tempCard != null) answer.append(tempCard.toString());
        answer.append("\n\nyour hand:\n");
        int index = 0;
        for (Card card : currentPlayer.getDeck()) {
            index++;
            answer.append(index);
            answer.append(".");
            answer.append(card.getName());
            answer.append("\n");
        }
        answer.append("\nyour bench:\n");
        for (int i = 1; i <= 3; i++) {
            tempCard = currentPlayer.getCardInBench(i);
            answer.append(i);
            answer.append(".");
            if (tempCard != null) answer.append(tempCard.toString());
            answer.append("\n");
        }
        answer.append("\n");
        answer.append(nextPlayer.getUsername());
        answer.append("'s active card:\n");
        tempCard = nextPlayer.getCardInBench(0);
        if (tempCard != null) answer.append(tempCard.toString());
        answer.append("\n\n");
        answer.append(nextPlayer.getUsername());
        answer.append("'s bench:\n");
        for (int i = 1; i <= 3; i++) {
            tempCard = nextPlayer.getCardInBench(i);
            answer.append(i);
            answer.append(".");
            if (tempCard != null) answer.append(tempCard.toString());
            answer.append("\n");
        }
        return answer.toString();
    }

    public static String showPlayerInfo(User player, int placeNumber) {
        if (placeNumber < 0 || placeNumber > 3) return "invalid place number\n";
        Card card = player.getCardInBench(placeNumber);
        if (card == null) return "no pokemon in the selected place\n";
        StringBuilder answer = new StringBuilder("");
        answer.append("pokemon: ");
        answer.append(card.getName());
        answer.append("\nspecial condition: ");
        if (card.isBurning()) answer.append("burning\nhitpoint: ");
        else if (card.isSleeping()) answer.append("sleep\nhitpoint: ");
        else answer.append("\nhitpoint: ");
        answer.append(String.format("%.2f", card.getHitpoint()));
        answer.append("/");
        answer.append(String.format("%.2f", (double) Card.getMaxhitpointByName(card.getName())));
        answer.append("\nenergy 1: ");
        Card energy = card.getEnergyInEnergies(0);
        if (energy != null) answer.append(energy.getName());
        answer.append("\nenergy 2: ");
        energy = card.getEnergyInEnergies(1);
        if (energy != null) answer.append(energy.getName());
        answer.append("\n");
        return answer.toString();
    }

    public static String showCurrentPlayerInfo(Matcher matcher) {
        int placeNumber = Integer.valueOf(matcher.group("placeNumber"));
        Game currentGame = Game.getCurrentGame();
        User currentPlayer = currentGame.getCurrentPlayer();
        return showPlayerInfo(currentPlayer, placeNumber);
    }

    public static String showNextPlayerInfo(Matcher matcher) {
        int placeNumber = Integer.valueOf(matcher.group("placeNumber"));
        Game currentGame = Game.getCurrentGame();
        User nextPlayer = currentGame.getNextPlayer();
        return showPlayerInfo(nextPlayer, placeNumber);
    }

    public static String putCard(Matcher matcher) {
        String cardName = matcher.group("cardName");
        int placeNumber = Integer.valueOf(matcher.group("placeNumber"));
        Game currentGame = Game.getCurrentGame();
        User currentPlayer = currentGame.getCurrentPlayer();
        if (!Card.isValidCardName(cardName)) return "card name is invalid";
        Card card = currentPlayer.getCardInDeckByName(cardName);
        if (card == null) return "you don't have the selected card";
        if (placeNumber < 0 || placeNumber > 3) return "invalid place number";
        Card cardInBench = currentPlayer.getCardInBench(placeNumber);
        if (card.isPokemon() && cardInBench != null) return "a pokemon already exists there";
        if (card.isEnergy() && cardInBench == null) return "no pokemon in the selected place";
        if (cardInBench != null) {
            if (card.isEnergy() && (!cardInBench.canAddEnergy())) return "pokemon already has 2 energies";
        }
        if (card.isEnergy() && currentGame.hasUsedEnergy()) return "you have already played an energy card in this turn";
        if (card.isEnergy()) {
            if (cardInBench != null) {
                cardInBench.addEnergy(card);
                currentGame.setUsedEnergy(true);
            }
        }
        else currentPlayer.addToBench(card, placeNumber);
        currentPlayer.removeFromDeck(card);
        currentPlayer.removeFromCards(card);
        return "card put successful";
    }

    public static String substituteCard(Matcher matcher) {
        int placeNumber = Integer.valueOf(matcher.group("placeNumber"));
        if (placeNumber < 1 || placeNumber > 3) return "invalid bench number";
        Game currentGame = Game.getCurrentGame();
        User currentPlayer = currentGame.getCurrentPlayer();
        Card cardInPlace = currentPlayer.getCardInBench(placeNumber);
        if (cardInPlace == null) return "no pokemon in the selected place";
        Card activeCard = currentPlayer.getCardInBench(0);
        if (activeCard != null) {
            if (activeCard.isSleeping()) return "active pokemon is sleeping";
        }
        currentPlayer.substituteActiveCard(placeNumber);
        return "substitution successful";
    }

    public static void checkPlayerCards(User player) {
        Game currentGame = Game.getCurrentGame();
        for (int i = 0; i < 4; i++) {
            Card card = player.getCardInBench(i);
            if (card == null) continue;
            if (card.isBurning() && card.getType().equals("fire")) card.takeDamageOrHeal(-10d);
            card.setBurning(false);
            card.setSleeping(false);
            double maxHitpoint = Card.getMaxhitpointByName(card.getName());
            if (card.getHitpoint() > maxHitpoint) {
                card.setHitpoint(maxHitpoint);
                continue;
            }
            if (card.getHitpoint() < 0d) {
                card.setHitpoint(0d);
                currentGame.killCard(card);
                player.setCardInBench(null, i);
            }
        }
        return;
    }

    public static void addReduces(User player) {
        Game currentGame = Game.getCurrentGame();
        User enemy = currentGame.getOtherPlayer(player);
        for (int i = 0; i < 4; i++) {
            Card card = player.getCardInBench(i);
            if (card == null) continue;
            double reduced = (double) Card.getMaxhitpointByName(card.getName()) - card.getHitpoint();
            enemy.setReduce(enemy.getReduce() + reduced);
        }
        return;
    }

    public static void calculateScore(User player) {
        player.setExperience(player.getExperience() + 10 * player.getKills());
        player.setCoins(player.getCoins() + (int) Math.floor(player.getReduce() / 10d));
        return;
    }

    public static String endTurn(boolean hasDoneAction) {
        Game currentGame = Game.getCurrentGame();
        User currentPlayer = currentGame.getCurrentPlayer();
        User nextPlayer = currentGame.getNextPlayer();
        User firstPlayer = currentGame.getGameStarterUser();
        if (firstPlayer == nextPlayer) currentGame.increaseRoundNumber();
        currentGame.setUsedEnergy(false);
        checkPlayerCards(currentPlayer);
        checkPlayerCards(nextPlayer);
        for (Card card : currentGame.getBurningInNextRound()) {
            card.setBurning(true);
        }
        for (Card card : currentGame.getSleepingInNextRound()) {
            card.setSleeping(true);
        }
        currentGame.clearBurningInNextRound();
        currentGame.clearSleepingInNextRound();
        if (currentPlayer.getCardInBench(0) != null) {
            String answer = "";
            if (hasDoneAction) answer = "action executed successfully\n";
            currentGame.setCurrentPlayer(nextPlayer);
            currentGame.setNextPlayer(currentPlayer);
            return answer + currentGame.getCurrentPlayer().getUsername() + "'s turn";
        }
        addReduces(currentPlayer);
        addReduces(nextPlayer);
        calculateScore(currentPlayer);
        calculateScore(nextPlayer);
        return "Winner: " + nextPlayer.getUsername();
    }

    public static String doAction(Matcher matcher) {
        Game currentGame = Game.getCurrentGame();
        User currentPlayer = currentGame.getCurrentPlayer();
        User nextPlayer = currentGame.getNextPlayer();
        Card defender = nextPlayer.getCardInBench(0);
        Card activeCard = currentPlayer.getCardInBench(0);
        if (activeCard == null) return "no active pokemon";
        boolean needTarget = (activeCard.getName().equals("ducklett") || activeCard.getName().equals("rowlet"));
        String target = matcher.group("target");
        boolean haveTarget = (target != null);
        if (haveTarget != needTarget) return "invalid action";
        int targetNumber = -1;
        if (target != null) {
            targetNumber = Integer.valueOf(target);
            if (activeCard.getName().equals("ducklett")) {
                if (targetNumber < 0 || targetNumber > 3) return "invalid target number";
            }
            if (activeCard.getName().equals("rowlet")) {
                if (targetNumber < 1 || targetNumber > 3) return "invalid target number";
            }
            if (activeCard.getName().equals("ducklett")) defender = nextPlayer.getCardInBench(targetNumber);
            else defender = currentPlayer.getCardInBench(targetNumber);
        }
        if (defender == null) return "no pokemon in the selected place";
        if (activeCard.isSleeping()) return "active pokemon is sleeping";
        double damageOrHealAmount = 0d;
        if (activeCard.getName().equals("dragonite")) {
            damageOrHealAmount = activeCard.getDamageOrHealAmount(defender.getName());
            defender.takeDamageOrHeal(damageOrHealAmount);
            if (!defender.getType().equals("water")) currentGame.addToBurningInNextRound(defender);
            activeCard.removeOneEnergy();
        } else if (activeCard.getName().equals("tepig")) {
            for (int i = 0; i < 4; i++) {
                defender = nextPlayer.getCardInBench(i);
                if (defender == null) continue;
                damageOrHealAmount = activeCard.getDamageOrHealAmount(defender.getName());
                if (i != 0) damageOrHealAmount *= 0.2d;
                defender.takeDamageOrHeal(damageOrHealAmount);
                if (!defender.getType().equals("water")) currentGame.addToBurningInNextRound(defender);
            }
            activeCard.removeOneEnergy();
        } else if (activeCard.getName().equals("lugia")) {
            damageOrHealAmount = activeCard.getDamageOrHealAmount(defender.getName());
            defender.takeDamageOrHeal(damageOrHealAmount);
            currentGame.addToSleepingInNextRound(defender);
            activeCard.removeOneEnergy();
        } else if (activeCard.getName().equals("ducklett")) {
            defender = nextPlayer.getCardInBench(targetNumber);
            damageOrHealAmount = activeCard.getDamageOrHealAmount(defender.getName());
            defender.takeDamageOrHeal(damageOrHealAmount);
            defender.paralyze();
            activeCard.removeOneEnergy();
        } else if (activeCard.getName().equals("pineco")) {
            defender = activeCard;
            damageOrHealAmount = activeCard.getDamageOrHealAmount(defender.getName());
            defender.takeDamageOrHeal(damageOrHealAmount);
            activeCard.removeOneEnergy();
        } else if (activeCard.getName().equals("rowlet")) {
            defender = currentPlayer.getCardInBench(targetNumber);
            damageOrHealAmount = activeCard.getDamageOrHealAmount(defender.getName());
            defender.takeDamageOrHeal(damageOrHealAmount);
            activeCard.removeOneEnergy();
        }
        return endTurn(true);
    }

}
