package controller;

import model.Card;
import model.User;

import java.util.regex.Matcher;

public class ShopMenuController {

    public static String buyCard(Matcher matcher) {
        String cardName = matcher.group("cardName");
        if (!Card.isValidCardName(cardName)) return "card name is invalid";
        User loggedInUser = User.getLoggedInUser();
        if (!loggedInUser.canBuyCard(cardName)) return "not enough coin to buy " + cardName;
        loggedInUser.buyCard(cardName);
        return "card " + cardName + " bought successfully";
    }

    public static String sellCard(Matcher matcher) {
        String cardName = matcher.group("cardName");
        if (!Card.isValidCardName(cardName)) return "card name is invalid";
        User loggedInUser = User.getLoggedInUser();
        Card card = loggedInUser.getCardInCardsByName(cardName);
        if (card == null) return "you don't have this type of card for sell";
        loggedInUser.sellCard(card);
        return "card " + cardName + " sold successfully";
    }

}
