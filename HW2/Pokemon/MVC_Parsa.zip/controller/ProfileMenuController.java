package controller;

import model.*;

import java.util.ArrayList;
import java.util.regex.Matcher;

public class ProfileMenuController {

    public static String showCoins() {
        User loggedInUser = User.getLoggedInUser();
        return "number of coins:" + loggedInUser.getCoins();
    }

    public static String showExperience() {
        User loggedInUser = User.getLoggedInUser();
        return "experience:" + loggedInUser.getExperience();
    }

    public static String showStorage() {
        User loggedInUser = User.getLoggedInUser();
        StringBuilder answer = new StringBuilder("");
        int index = 0;
        for (Card card : loggedInUser.getCards()) {
            index++;
            answer.append(index);
            answer.append(".");
            answer.append(card.getType());
            answer.append(" ");
            answer.append(card.getName());
            answer.append(" ");
            answer.append(Card.getBuyPriceByName(card.getName()));
            answer.append("\n");
        }
        return answer.toString();
    }

    public static String equipCard(Matcher matcher) {
        String cardName = matcher.group("cardName");
        if (!Card.isValidCardName(cardName)) return "card name is invalid";
        User loggedInUser = User.getLoggedInUser();
        Card card = loggedInUser.getCardInCardsMinusDeckByName(cardName);
        if (card == null) return "you don't have this type of card";
        if (loggedInUser.hasFullDeck()) return "your deck is already full";
        if (card.isPokemon() && loggedInUser.getCardInDeckByName(cardName) != null) return "you have already added this type of pokemon to your deck";
        loggedInUser.equipToDeck(card);
        return "card " + cardName + " equipped to your deck successfully";
    }

    public static String unequipCard(Matcher matcher) {
        String cardName = matcher.group("cardName");
        if (!Card.isValidCardName(cardName)) return "card name is invalid";
        User loggedInUser = User.getLoggedInUser();
        Card card = loggedInUser.getCardInDeckByName(cardName);
        if (card == null) return "you don't have this type of card in your deck";
        loggedInUser.unequipFromDeck(card);
        return "card " + cardName + " unequipped from your deck successfully";
    }

    public static String showDeck() {
        StringBuilder answer = new StringBuilder("");
        User loggedInUser = User.getLoggedInUser();
        int index = 0;
        for (Card card : loggedInUser.getDeck()) {
            index++;
            answer.append(index);
            answer.append(".");
            answer.append(card.getName());
            answer.append("\n");
        }
        return answer.toString();
    }

    public static String showRank() {
        User loggedInUser = User.getLoggedInUser();
        return "your rank:" + loggedInUser.getRank();
    }

    public static String showRanking() {
        ArrayList<User> ranking = User.getSortedRanking();
        StringBuilder answer = new StringBuilder("");
        int index = 0;
        for (User user : ranking) {
            index++;
            answer.append(index);
            answer.append(".username:");
            answer.append(user.getUsername());
            answer.append(" experience:");
            answer.append(user.getExperience());
            answer.append("\n");
        }
        return answer.toString();
    }

}
