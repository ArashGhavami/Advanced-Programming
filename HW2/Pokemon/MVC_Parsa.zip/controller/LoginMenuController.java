package controller;

import model.User;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginMenuController {

    public static String registerUser(Matcher matcher) {
        String username = matcher.group("username");
        if (!hasCorrectUsernameFormat(username)) return "username format is invalid";
        if (User.getUserByUsername(username) != null) return "username already exists";
        String password = matcher.group("password");
        if (password.length() < 6 || password.length() > 18) return "password length too small or short";
        if (!hasSpecialCharacter(password)) return "your password must have at least one special character";
        if (!hasCorrectPasswordFormat(password)) return "your password must start with english letters";
        String email = matcher.group("email");
        Matcher emailMatcher = Pattern.compile("(?<address>\\S+)@([a-z]+\\.com)").matcher(email);
        if (!hasCorrectEmailFormat(emailMatcher)) return "email format is invalid";
        String address = emailMatcher.group("address");
        if (!hasCorrectAddressFormat(address)) return "you can't use special characters";
        User user = new User(username, password, email);
        User.addUser(user);
        return "user registered successfully";
    }

    public static String loginUser(Matcher matcher) {
        User user = User.getUserByUsername(matcher.group("username"));
        if (user == null) return "username doesn't exist";
        if (!user.getPassword().equals(matcher.group("password"))) return "password is incorrect";
        User.setLoggedInUser(user);
        return "user logged in successfully";
    }

    private static boolean hasCorrectUsernameFormat(String username) {
        return (Pattern.compile("[a-zA-Z_]+").matcher(username).matches());
    }

    private static boolean hasSpecialCharacter(String password) {
        return (Pattern.compile("(?=.*[@#$^&!]{1}).+").matcher(password).matches());
    }

    private static boolean hasCorrectPasswordFormat(String password) {
        return (Pattern.compile("[a-zA-Z]{1}.*").matcher(password).matches());
    }

    private static boolean hasCorrectEmailFormat(Matcher emailMatcher) {
        return (emailMatcher.matches());
    }

    private static boolean hasCorrectAddressFormat(String address) {
        if (!Pattern.compile("[a-zA-Z0-9.]+").matcher(address).matches()) return false;
        int dotCounter = 0;
        for (int i = 0; i < address.length(); i++) {
            if (address.charAt(i) == '.') dotCounter++;
        }
        return (dotCounter <= 1);
    }
}
