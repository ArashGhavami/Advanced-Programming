package view;

import controller.LoginMenuController;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginMenuView {

    private static Matcher getCommandMatcher(String input, String regex) {
        return Pattern.compile(regex).matcher(input);
    }

    public static void run(Scanner scanner) {
        String input = "";
        Matcher matcher;
        while (true) {
            input = scanner.nextLine();
            input = input.trim();
            if (input.equals("exit")) {
                return;
            } else if (input.equals("show current menu")) {
                System.out.println("login menu");
            } else if ((matcher = getCommandMatcher(input,
                    "register\\s+username\\s+(?<username>\\S+)\\s+password\\s+(?<password>\\S+)\\s+email\\s+(?<email>\\S+)")).matches()) {
                System.out.println(LoginMenuController.registerUser(matcher));
            } else if ((matcher = getCommandMatcher(input, "login\\s+username\\s+(?<username>\\S+)\\s+password\\s+(?<password>\\S+)")).matches()) {
                String answer = LoginMenuController.loginUser(matcher);
                System.out.println(answer);
                if (answer.equals("user logged in successfully")) {
                    MainMenuView.run(scanner);
                    return;
                }
            } else {
                System.out.println("invalid command");
            }
        }
    }
}
