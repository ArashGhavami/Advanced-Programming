package view;

import controller.MainMenuController;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainMenuView {

    private static Matcher getCommandMatcher(String input, String regex) {
        return Pattern.compile(regex).matcher(input);
    }

    public static void run(Scanner scanner) {
        String input = "";
        Matcher matcher;
        while (true) {
            input = scanner.nextLine();
            input = input.trim();
            if (input.equals("logout")) {
                LoginMenuView.run(scanner);
                return;
            } if (input.equals("show current menu")) {
                System.out.println("main menu");
            } else if (input.equals("go to shop menu")) {
                ShopMenuView.run(scanner);
                return;
            } else if (input.equals("go to profile menu")) {
                ProfileMenuView.run(scanner);
                return;
            } else if ((matcher = getCommandMatcher(input, "start new game with (?<username>\\S+)")).matches()) {
                String answer = MainMenuController.startNewGame(matcher);
                if (!answer.equals("ok")) System.out.println(answer);
                else {
                    GameMenuView.run(scanner);
                    return;
                }
            } else {
                System.out.println("invalid command");
            }
        }
    }
}
