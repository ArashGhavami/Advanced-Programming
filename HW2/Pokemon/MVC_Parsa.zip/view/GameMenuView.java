package view;

import controller.GameMenuController;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GameMenuView {

    private static Matcher getCommandMatcher(String input, String regex) {
        return Pattern.compile(regex).matcher(input);
    }

    public static void run(Scanner scanner) {
        String input = "";
        Matcher matcher;
        while (true) {
            input = scanner.nextLine();
            input = input.trim();
            if (input.equals("show current menu")) {
                System.out.println("game menu");
            } else if (input.equals("show table")) {
                System.out.print(GameMenuController.showTable());
            } else if ((matcher = getCommandMatcher(input, "show my info (?<placeNumber>\\d+)")).matches()) {
                System.out.print(GameMenuController.showCurrentPlayerInfo(matcher));
            } else if ((matcher = getCommandMatcher(input, "show enemy info (?<placeNumber>\\d+)")).matches()) {
                System.out.print(GameMenuController.showNextPlayerInfo(matcher));
            } else if ((matcher = getCommandMatcher(input, "put card (?<cardName>\\S+) to (?<placeNumber>\\d+)")).matches()) {
                System.out.println(GameMenuController.putCard(matcher));
            } else if ((matcher = getCommandMatcher(input, "substitute active card with bench (?<placeNumber>\\d+)")).matches()) {
                System.out.println(GameMenuController.substituteCard(matcher));
            } else if (input.equals("end turn")) {
                String answer = GameMenuController.endTurn(false);
                System.out.println(answer);
                if (answer.startsWith("Winner: ")) {
                    MainMenuView.run(scanner);
                    return;
                }
            } else if ((matcher = getCommandMatcher(input, "execute action( -t (?<target>\\d+))?")).matches()) {
                String answer = GameMenuController.doAction(matcher);
                System.out.println(answer);
                if (answer.startsWith("Winner: ")) {
                    MainMenuView.run(scanner);
                    return;
                }
            } else {
                System.out.println("invalid command");
            }
        }
    }
}
