package view;

import controller.ShopMenuController;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ShopMenuView {

    private static Matcher getCommandMatcher(String input, String regex) {
        return Pattern.compile(regex).matcher(input);
    }

    public static void run(Scanner scanner) {
        String input = "";
        Matcher matcher;
        while (true) {
            input = scanner.nextLine();
            input = input.trim();
            if (input.equals("back")) {
                MainMenuView.run(scanner);
                return;
            } else if (input.equals("show current menu")) {
                System.out.println("shop menu");
            } else if ((matcher = getCommandMatcher(input, "buy card (?<cardName>\\S+)")).matches()) {
                System.out.println(ShopMenuController.buyCard(matcher));
            } else if ((matcher = getCommandMatcher(input, "sell card (?<cardName>\\S+)")).matches()) {
                System.out.println(ShopMenuController.sellCard(matcher));
            }
            else {
                System.out.println("invalid command");
            }
        }
    }
}
