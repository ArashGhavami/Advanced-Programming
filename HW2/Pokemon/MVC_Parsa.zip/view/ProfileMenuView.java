package view;

import controller.ProfileMenuController;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProfileMenuView {

    private static Matcher getCommandMatcher(String input, String regex) {
        return Pattern.compile(regex).matcher(input);
    }

    public static void run(Scanner scanner) {
        String input = "";
        Matcher matcher;
        while (true) {
            input = scanner.nextLine();
            input = input.trim();
            if (input.equals("back")) {
                MainMenuView.run(scanner);
                return;
            } else if (input.equals("show current menu")) {
                System.out.println("profile menu");
            } else if (input.equals("show coins")) {
                System.out.println(ProfileMenuController.showCoins());
            } else if (input.equals("show experience")) {
                System.out.println(ProfileMenuController.showExperience());
            } else if (input.equals("show storage")) {
                System.out.print(ProfileMenuController.showStorage());
            } else if ((matcher = getCommandMatcher(input, "equip card (?<cardName>\\S+) to my deck")).matches())  {
                System.out.println(ProfileMenuController.equipCard(matcher));
            } else if ((matcher = getCommandMatcher(input, "unequip card (?<cardName>\\S+) from my deck")).matches()) {
                System.out.println(ProfileMenuController.unequipCard(matcher));
            } else if (input.equals("show my deck")) {
                System.out.print(ProfileMenuController.showDeck());
            } else if (input.equals("show my rank")) {
                System.out.println(ProfileMenuController.showRank());
            } else if (input.equals("show ranking")) {
                System.out.print(ProfileMenuController.showRanking());
            } else {
                System.out.println("invalid command");
            }
        }
    }
}
